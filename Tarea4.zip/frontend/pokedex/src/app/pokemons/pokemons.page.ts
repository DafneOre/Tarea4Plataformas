import { Component, OnInit } from '@angular/core';
import { range } from 'rxjs';
import { ServicesService } from '../_services/services.service';

@Component({
  selector: 'app-pokemons',
  templateUrl: './pokemons.page.html',
  styleUrls: ['./pokemons.page.scss'],
})
export class PokemonsPage implements OnInit {
  pokemons:any [];
  suma:string="";
  constructor(
    private servicesservice: ServicesService
  ) { }

  ngOnInit() {
  }

  ionViewWillEnter():void{ 
    this.servicesservice.getPokemons().subscribe(data=>{
      this.pokemons=data;
      console.log(data);
    })
  }

}
