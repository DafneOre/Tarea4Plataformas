import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesService } from 'src/app/_services/services.service';

@Component({
  selector: 'app-pokemon-edit',
  templateUrl: './pokemon-edit.page.html',
  styleUrls: ['./pokemon-edit.page.scss'],
})
export class PokemonEditPage implements OnInit {
  pokemon_id:any;
  pokemon:any;
  pokemonsForm:FormGroup
  constructor(
    private servicesservice:ServicesService,
    private activatedRoute:ActivatedRoute,
    private formBuilder:FormBuilder,
    private router:Router 
  ) { 
    this.pokemonsForm=this.formBuilder.group({
      names:[''],
      weaknesses:[''],
      imagen:[''],
      height:[''],
      weights:[''],
      category:[''],
      abilities:[''],
      types:['']
    })
  }
  ngOnInit() {    
    this.activatedRoute.paramMap.subscribe(
      data=>{
        this.pokemon_id=data.get('id');
        this.servicesservice.getPokemonsById(this.pokemon_id).subscribe(
          response=>{
            console.log(response)
            this.pokemon=response;
            this.pokemonsForm.patchValue(response);
          },
          error=>{console.log(error);}
        )
      }
    );
  }

  updatePokemon(values:any){
    this.servicesservice.updatePokemon(this.pokemon_id,values).subscribe(
      response=>{
        console.log(response);
        this.router.navigate(['/pokemons']);
      },
      error=>{
        console.log(error);
        
      }
      )
  }
  
}