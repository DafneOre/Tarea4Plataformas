import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ServicesService } from '../../_services/services.service';

@Component({
  selector: 'app-pokemon-view',
  templateUrl: './pokemon-view.page.html',
  styleUrls: ['./pokemon-view.page.scss'],
})
export class PokemonViewPage implements OnInit {
  date_pokemon:any;
  constructor(
    private activadedRoute: ActivatedRoute,
    private servicesservice:ServicesService
  ) { }

  ngOnInit() {
    this.activadedRoute.paramMap.subscribe(
      data=>{
        const id=data.get('id');
        this.servicesservice.getPokemonsById(id).subscribe(
          response=>{
            console.log(response);
            this.date_pokemon=response;
          },
          error=>{
            console.log(error);
          }
        )
      }
    )
  }

}