import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServicesService } from 'src/app/_services/services.service';

@Component({
  selector: 'app-pokemon-delete',
  templateUrl: './pokemon-delete.page.html',
  styleUrls: ['./pokemon-delete.page.scss'],
})
export class PokemonDeletePage implements OnInit {
  pokemon_id:any;
  pokemon_date:any;
  constructor(
    private activatedRoute:ActivatedRoute, 
    private servicesservice:ServicesService, 
    private router:Router 
  ) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(
      data=>{
        this.pokemon_id=data.get('id'); 
        this.servicesservice.getPokemonsById(this.pokemon_id).subscribe(
          response=>{
            console.log(response)
            this.pokemon_date=response;
          },
          error=>{console.log(error);}
        )
      }
    )
  }
  deletePokemon(pokemon_id:any){ 
    this.servicesservice.deletePokemon(this.pokemon_id).subscribe(
      response=>{
        console.log(response);
        this.pokemon_date=response;
        this.router.navigate(['/pokemons'])
      },
      error=>{
        console.log(error);}
    )
  }
  

}