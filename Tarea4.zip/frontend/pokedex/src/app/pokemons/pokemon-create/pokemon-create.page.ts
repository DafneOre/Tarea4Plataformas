import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ServicesService } from '../../_services/services.service';

@Component({
  selector: 'app-pokemon-create',
  templateUrl: './pokemon-create.page.html',
  styleUrls: ['./pokemon-create.page.scss'],
})
export class PokemonCreatePage implements OnInit {
  pokemonsForm : FormGroup;
  constructor(
    private formBuilder:FormBuilder,
    private servicesservice:ServicesService,
    private router: Router
  ) { 
    this.pokemonsForm=this.formBuilder.group({      
      names:[''],
      weaknesses:[''],
      imagen:[''],
      height:[''],
      weights:[''],
      category:[''],
      abilities:[''],
      types:['']

    })
  }
  ngOnInit() {
  }
  addPokemon(values:any){
    this.servicesservice.insertPokemon(values).subscribe(
      response=> {
        console.log(response);
        this.router.navigate(['/pokemons']);
      },
      error=>{
        console.log(error);
      }  
    )
  }
}